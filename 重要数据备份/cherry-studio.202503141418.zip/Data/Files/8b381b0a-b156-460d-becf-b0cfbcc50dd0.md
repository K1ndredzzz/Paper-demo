### 3.1 评论数据预处理

```python
# 评论数据预处理示例代码
import pandas as pd
import re
import jieba

def preprocess_comments(raw_data_path, output_path):
    # 读取原始评论数据
    df = pd.read_csv(raw_data_path, encoding='utf-8')
    
    # 数据清洗
    df['clean_comment'] = df['comment'].apply(lambda x: re.sub(r'[^\w\s]', '', str(x)))
    df['clean_comment'] = df['clean_comment'].apply(lambda x: re.sub(r'\s+', ' ', x.strip()))
    
    # 广告过滤
    ad_keywords = ['开户', '加微信', '加QQ', '电报群', '推荐股', '老师', '信号', '指导', 
                  '带飞', '操作建议', '直播间', '免费分析', '牛股', '加我', '联系我']
    
    def filter_ads(text):
        for keyword in ad_keywords:
            if keyword in text:
                return True
        return False
    
    # 过滤广告和短内容
    df = df[~df['clean_comment'].apply(filter_ads)]
    df = df[df['clean_comment'].str.len() >= 5]
    
    # 添加时间特征
    df['date'] = pd.to_datetime(df['timestamp']).dt.date
    df['hour'] = pd.to_datetime(df['timestamp']).dt.hour
    
    # 分词
    df['tokens'] = df['clean_comment'].apply(lambda x: ' '.join(jieba.cut(x)))
    
    # 保存处理后的数据
    df.to_csv(output_path, index=False, encoding='utf-8')
    
    return df
```
## 四、情绪分析模型构建

### 4.1 零样本情感分析模型

```python
from transformers import AutoModelForSequenceClassification, AutoTokenizer, pipeline
import torch
import numpy as np

class ZeroShotSentimentAnalyzer:
    def __init__(self, model_name='IDEA-CCNL/Ernie-3.0-base-zh'):
        """
        初始化零样本金融情感分析器
        
        Args:
            model_name (str): 预训练模型名称或路径
                推荐模型:
                - 'IDEA-CCNL/Ernie-3.0-base-zh': 中文ERNIE
                - 'hfl/chinese-roberta-wwm-ext': 中文RoBERTa
                - 'nghuyong/ernie-3.0-base-zh': 另一个中文ERNIE实现
        """
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForSequenceClassification.from_pretrained(model_name)
        self.model.to(self.device)
        self.model.eval()
        
        # 定义情感类别对应的模板文本
        self.templates = {
            "负面": ["这条评论表达了负面情绪", "这是一条看跌的评论", "这条评论持悲观态度"],
            "中性": ["这条评论表达了中性情绪", "这是一条客观的评论", "这条评论没有明显的情感倾向"],
            "正面": ["这条评论表达了正面情绪", "这是一条看涨的评论", "这条评论持乐观态度"]
        }
        
        # 情感标签映射 (负面:-1, 中性:0, 正面:1)
        self.label_map = {"负面": -1, "中性": 0, "正面": 1}
    
    def predict_sentiment(self, text):
        """预测单条文本的情感"""
        scores = {}
        
        # 对每种情感类别计算得分
        for sentiment, prompts in self.templates.items():
            sentiment_scores = []
            
            for prompt in prompts:
                # 构建输入
                input_text = f"{text} {prompt}"
                inputs = self.tokenizer(input_text, return_tensors="pt", padding=True, truncation=True, max_length=512)
                inputs = {k: v.to(self.device) for k, v in inputs.items()}
                
                # 计算得分
                with torch.no_grad():
                    outputs = self.model(**inputs)
                    logits = outputs.logits
                    probs = torch.softmax(logits, dim=-1)
                    sentiment_scores.append(float(probs[0][1]))  # 取第二个类别的概率作为正类概率
            
            # 取平均得分
            scores[sentiment] = np.mean(sentiment_scores)
        
        # 归一化得分
        total = sum(scores.values())
        normalized_scores = {k: v / total for k, v in scores.items()}
        
        # 确定最可能的情感极性
        polarity = self.label_map[max(normalized_scores, key=normalized_scores.get)]
        
        # 计算情感得分 (正面概率 - 负面概率)
        score = normalized_scores["正面"] - normalized_scores["负面"]
        
        # 计算情感强度 (最高概率与次高概率的差距)
        sorted_probs = sorted(normalized_scores.values(), reverse=True)
        intensity = sorted_probs[0] - sorted_probs[1]
        
        return {
            'score': float(score),
            'polarity': int(polarity),
            'intensity': float(intensity),
            'positive_prob': float(normalized_scores["正面"]),
            'neutral_prob': float(normalized_scores["中性"]),
            'negative_prob': float(normalized_scores["负面"])
        }
    
    def predict_batch(self, texts, batch_size=16):
        """批量预测多条文本的情感"""
        results = []
        
        for i in range(0, len(texts), batch_size):
            batch_texts = texts[i:i+batch_size]
            batch_results = [self.predict_sentiment(text) for text in batch_texts]
            results.extend(batch_results)
        
        return results
```

### 4.2 情感分析验证与评估

```python
def validate_sentiment_model(analyzer, sample_comments, output_path='validation_results.csv'):
    """
    验证情感分析模型的效果
    
    Args:
        analyzer: 情感分析模型
        sample_comments: 样本评论列表
        output_path: 验证结果保存路径
    
    Returns:
        验证结果DataFrame
    """
    import random
    
    # 随机抽样进行验证（如果样本量太大）
    if len(sample_comments) > 100:
        validation_sample = random.sample(sample_comments, 100)
    else:
        validation_sample = sample_comments
    
    # 进行情感预测
    predictions = []
    for comment in validation_sample:
        result = analyzer.predict_sentiment(comment)
        sentiment_label = "正面" if result["polarity"] == 1 else ("负面" if result["polarity"] == -1 else "中性")
        
        predictions.append({
            "text": comment,
            "predicted_sentiment": sentiment_label,
            "score": result["score"],
            "positive_prob": result["positive_prob"],
            "neutral_prob": result["neutral_prob"],
            "negative_prob": result["negative_prob"],
            "intensity": result["intensity"]
        })
    
    # 保存验证结果
    df = pd.DataFrame(predictions)
    df.to_csv(output_path, index=False, encoding='utf-8')
    print(f"已保存验证结果至: {output_path}")
    
    # 打印情感分布统计
    sentiment_counts = df['predicted_sentiment'].value_counts()
    print("\n情感分布统计:")
    for sentiment, count in sentiment_counts.items():
        print(f"{sentiment}: {count} ({count/len(df)*100:.1f}%)")
    
    return df
```